package javaproject;

public class Student {

	private String sName,sDOB,sAddress,sEmail,sHqual,sPhoneNo,sNationality;
	private String sAdmissionId;
	private String sResult;
	private Exam sExam;
	
	public Student (String name, String DOB, String address, String email, String hqual,String phoneno,String nationality ) {
		this.sName = name;
		this.sDOB = DOB;
		this.sAddress = address;
		this.sEmail = email;
		this.sHqual = hqual;
		this.sPhoneNo = phoneno;
		this.sNationality = nationality;
	}
	
	
	public String getsName() {
		return sName;
	}

	public String getsDOB() {
		return sDOB;
	}

	public String getsAddress() {
		return sAddress;
	}

	public String getsEmail() {
		return sEmail;
	}
	public String getsHqual() {
		return sHqual;
	}
	public String getsPhoneNo() {
		return sPhoneNo;
	}
	public String getsNationality() {
		return sNationality;
	}
	public String getsAdmissionId() {
		return sAdmissionId;
	}
	public String getsResult() {
		return sResult;
	}
	public Exam getsExam() {
		return sExam;
	}
	public void registerForAdmission() {
		Registrar registrar = Registrar.getRegistrar();
		sAdmissionId = registrar.registerStudent(this);
	}
	
	public void registerForExam() {
		examRegistrar examiner = examRegistrar.getExamRegistrar();
		sExam = examiner.registeringStudentForExamination(this);
	}
	
	public void appearForExam() {
		Paper paper1 = this.sExam.getPaper();
		sResult = paper1.submit();
			}
}
