package javaproject;

public class Paper {
	
	String result;
	
	public String submit () {
		Evaluator evaluator = Evaluator.getEvaluator();
		result = evaluator.evaluate(this);
		return result;
	}

}
