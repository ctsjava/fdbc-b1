package javaproject;

import java.util.Random;

public class Registrar {
	
	String adminS;
	
	private static Registrar obj = null;
	
	private Registrar () {
		
	}
	
	public static Registrar getRegistrar() {
		if (obj == null) {
			obj = new Registrar();
		}
		return obj;
	}
	
	public String registerStudent( Student s1) {
		
		Validator val = Validator.getValidator();
		if (val.validateStudentDetails(s1) == true) {
			Random rand = new Random();
			int adminInt = rand.nextInt(1000000);
			adminS = String.valueOf(adminInt);
		}
		return adminS;
	}

}
