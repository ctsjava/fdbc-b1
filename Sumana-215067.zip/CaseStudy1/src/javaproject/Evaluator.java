package javaproject;

public class Evaluator {

	
	private static Evaluator obj = null;
	
	private Evaluator() {
		
	}
	
	public static Evaluator getEvaluator() {
		if (obj == null) {
			obj = new Evaluator();
		}
		return obj;
	}
	
	public String evaluate(Paper paper) {
		return "Pass";
	}
}
