package javaproject;

public class MainClass {

	public static void main(String[] args) {
		
		Student s1 = new Student("Sumana Pramanik" , "23-12-1984","7 Das Lane","pramaniksumana23@gmail.com","MCA","9830111111","Indian");
        System.out.println(" " +s1.getsName() + " applying for Admission ");
		s1.registerForAdmission();
		System.out.print(" Registration is successful.");
		System.out.println(" Admission ID generated "+ s1.getsAdmissionId());
		s1.registerForExam();
		s1.appearForExam();
		System.out.println(" Result for admission test for applicant "+ s1.getsName() + " is " + s1.getsResult());
		System.out.println(" ");
		System.out.println(" Student is successfully enrolled to university");
		System.out.println(" ");
		System.out.println(" -----------------------------------------------------");
		System.out.println(" Student Details ");
		System.out.println(" -----------------------------------------------------");
		System.out.println(" Name                   : " + s1.getsName());
		System.out.println(" Date of Birth          : " + s1.getsDOB());
		System.out.println(" Address                : " + s1.getsAddress());
		System.out.println(" Email Id               : " + s1.getsEmail());
		System.out.println(" Highest Qualification  : " + s1.getsHqual());
		System.out.println(" Phone no               : " + s1.getsPhoneNo());
		System.out.println(" Nationality            : " + s1.getsNationality());
		System.out.println(" Admission ID           : " + s1.getsAdmissionId());
		System.out.println(" -----------------------------------------------------");

	}

}
