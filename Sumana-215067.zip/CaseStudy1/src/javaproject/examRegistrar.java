package javaproject; 

public class examRegistrar {
	
	private static examRegistrar obj = null;
	
	private examRegistrar () {
		
	}
	
	public static examRegistrar getExamRegistrar() {
		
		if ( obj == null) {
			obj = new examRegistrar();
		}
		return obj;
		
	}
	
	public Exam registeringStudentForExamination (Student s1) {
		Paper paper = new Paper();
		Exam exam = new Exam(paper);
		return exam;
	}

}
