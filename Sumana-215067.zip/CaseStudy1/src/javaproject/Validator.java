package javaproject;

public class Validator {
	
	private static Validator obj = null;
	
	private Validator () {
		
	}
	
	public static Validator getValidator() {
		if (obj == null) {
			obj = new Validator();
		}	
		return obj;
	}
	
	public boolean validateStudentDetails( Student s1) {
		
		return true;
	}

}
