package com.niladri;

public class Validator 
{
	static private Validator val = null;

	private Validator()
	{
	}

	static Validator getValidator() 
	{
		if(val == null)
		{
			return new Validator();
		}
		else
		{
			return val;
		}
	}

	boolean validateStudentDetails(Student student)
	{
		System.out.println("Validated " + student);
		return true;
	}
}
