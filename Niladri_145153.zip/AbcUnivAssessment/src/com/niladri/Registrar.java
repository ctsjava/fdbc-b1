package com.niladri;

public class Registrar 
{
	private int id = 0;
	static private Registrar reg = null;

	private Registrar()
	{	   
	}

	static Registrar getRegistrar()
	{
		if(reg == null)
		{
			return new Registrar();
		}
		else
		{
			return reg;
		}
	}

	int registerStudent(Student student)
	{
		Validator validator=Validator.getValidator();

		if(validator.validateStudentDetails(student))
		{
			id =  student.hashCode();
		}
		return id;	  
	}

}
