package com.niladri;

public class ExamRegistrar 
{
	static private ExamRegistrar ereg = null;

	private ExamRegistrar()
	{   
	}

	static ExamRegistrar getExamRegistrar()
	{
		if(ereg == null)
		{
			return new ExamRegistrar();
		}
		else
		{
			return ereg;
		}
	}

	Exam registeringStudentForExamination (Student student)
	{
		Paper paper=new Paper();
		Exam exam=new Exam(paper);
		return exam;
	}
}
