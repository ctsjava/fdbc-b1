package com.niladri;

public class Evaluator 
{
	static private Evaluator eval = null;

	private Evaluator()
	{   
	}

	static Evaluator getEvaluator()
	{
		if(eval == null)
		{
			return new Evaluator();
		}
		else
		{
			return eval;
		}
	} 

	String evaluate(Paper paper)
	{
		return "Pass";
	}
}
