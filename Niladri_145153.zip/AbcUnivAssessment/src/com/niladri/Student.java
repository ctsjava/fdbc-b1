package com.niladri;

public class Student 
{

	private String name; 
	private int age;
	private char sex;
	private String phoneNumber;
	private String subject;

	private int admissionId;
	private String result;
	private Exam exam; 

	public Student(String name, int age, char sex, String phoneNumber,
			String subject) {
		this.name = name;
		this.age = age;
		this.sex = sex;
		this.phoneNumber = phoneNumber;
		this.subject = subject;
	}

	int registerStudent() 
	{
		Registrar registrar=Registrar.getRegistrar();
		admissionId = registrar.registerStudent(this);
		return admissionId;
	}

	String registerForExam()
	{
		ExamRegistrar  examRegistrar=ExamRegistrar.getExamRegistrar();
		exam=examRegistrar.registeringStudentForExamination(this);
		return "registered for exam";
	}

	String appearForExam()
	{
		Paper paper=exam.getPaper();
		result=paper.submit();
		return result;
	}

	@Override
	public String toString() {
		return "Student [Name=" + name + ", Age=" + age + ", Sex=" + sex
				+ ", Phone Number=" + phoneNumber + ", Subject=" + subject + "]";
	}

}
