package com.niladri;

public class Exam 
{
	Paper paper;

	Exam(Paper paper)
	{
		this.paper=paper;
	}

	Paper getPaper()
	{
		return paper;
	}
}
