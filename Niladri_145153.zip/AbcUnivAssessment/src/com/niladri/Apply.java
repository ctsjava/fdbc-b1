package com.niladri;

public class Apply {

	public static void main(String[] args) 
	{
		Student s1 = new Student("Niladri Hait", 36, 'M', "9830088776", "Java");

		System.out.println("------------------------------------------------------------------------------------");
		System.out.println("Registered " + s1 + " with ID: " + s1.registerStudent());
		System.out.println("------------------------------------------------------------------------------------");
		
		System.out.println(s1 + " " + s1.registerForExam());
		System.out.println("------------------------------------------------------------------------------------");

		System.out.println("Result for " + s1 + " is " + s1.appearForExam());
		System.out.println("------------------------------------------------------------------------------------");

	}

}
