package vicky;

public class Admission {

	public static void main(String[] args) {
	Student s = Student.getStudent();
	s.setAddress("Madhupur");
	s.setAge(29);
	s.setDateOfBirth("01/01/1990");
	s.setHighestQualification("Btech");
	s.setInterestedSubject("CSE");
	s.setMaritalStatus('M');
	s.setName("VIKASH KR GOND");
	s.setNationality("Indian");
	s.setPhoneNumber(223364);
	s.setPrimaryEmailId("vickygond143@gmail.com");
	s.setSecondaryEmailId("Vikash.Gond@cognizant.com");
	s.setSex('M');
	s.setAdmissionId(s.registerStudent());
	s.registerForExam();
	s.setResult(s.appearForExam());
	Student.display(s);

}

}