package vicky;

public class Registrar {
	private Registrar(){
	   
	}
	static Registrar getRegistrar(){
	 return new Registrar();
	}

	  String registerStudent(Student student){
		  Validator validator=Validator.getValidator();
		  if(validator. validateStudentDetails (student))
	{
	    //generate admission id and return it to the student
	     return ("CSE0715");
	}
	return("Failed");
	  }
	}