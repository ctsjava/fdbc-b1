package vicky;

public class Exam {
	private Exam(){
	   
	}
	static Exam getExam(){
		return new Exam();
	}
	Paper paper;
	
	Exam(Paper paper){
	this.paper=paper;
	}
	Paper getPaper(){
	 return paper;
	}
	}