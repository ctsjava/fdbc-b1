package com;

import java.util.Scanner;

public class Apply {
	
	public static void main(String[] args) 
	{
		Student student = new Student();
		
		//System.out.print("Enter name: ");
		@SuppressWarnings({ "resource", "unused" })
		Scanner sc = new Scanner(System.in);
		//student.setName(sc.next());
		student.setName("Mayurika Das");
		student.setMaritalStatus("Married");
		student.setAge(28);
		student.setGender("Female");
		student.setDateOfBirth("08/10/1991");
		student.setAddress("Kolkata");
		student.setPrimaryEmailId("mayurika@cognizant.com");
		student.setSecondaryEmailId("mayurika.das@cognizant.com");
		student.setPhoneNumber("9876543210");
		student.setInterestedSubject("Java");
		student.setHighestEduQualification("B.Tech in Infomation Technology");
		student.setNationality("Indian");
		
		System.out.println("=============================================================================");
		System.out.println("STUDENT DETAILS");
		System.out.println("---------------");
		System.out.println("Student Name: " + student.getName());
		System.out.println("Student Marital Status: " + student.getMaritalStatus());
		System.out.println("Student Age: " + student.getAge());
		System.out.println("Student Sex: " + student.getGender());
		System.out.println("Student DOB: " + student.getDateOfBirth());
		System.out.println("Student Address: " + student.getAddress());
		System.out.println("Student Primary Email Id: " + student.getPrimaryEmailId());
		System.out.println("Student Secondary Email Id: " + student.getSecondaryEmailId());
		System.out.println("Student Phone Number: " + student.getPhoneNumber());
		System.out.println("Student Interested Subject: " + student.getInterestedSubject());
		System.out.println("Student Highest Educational Qualification: " + student.getHighestEduQualification());
		System.out.println("Student Nationality: " + student.getNationality());
		System.out.println("=============================================================================");
		int admissionId = student.registerStudent();
		System.out.println("Registered " + student + " with ID: " + admissionId);
		System.out.println(student + " " + student.registerForExam());
		
		String result = student.appearForExam();
		System.out.println("The result for " + student + " is: " + result);
		
	}

}
