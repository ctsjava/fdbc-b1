package abcUniversity;
import java.util.Scanner;

public class Apply {

	public static void main(String[] args) {
		Student s1 = Student.getStudent();
		
		System.out.print("Enter name: ");
		Scanner sc = new Scanner(System.in);
		s1.setName(sc.next());
		s1.setAge(35);
		
		s1.setMaritalStatus("Married");
		s1.setSex('M');
		s1.setDob("25/01/1987");
		s1.setAddress("Kolkata");
		s1.setPrimaryEmail("sb.biswas@gmail.com");
		s1.setSecondaryEmail("sb.soumya@cts.com");
		s1.setPhNo(25930471);
		s1.setInterestedSubject("ECE");
		s1.setHighestEducation("MBA");
		s1.setNationality("Indian");
		
		int admissionId = s1.registerStudent();
		System.out.println("Registered " + s1 + " with ID: " + admissionId);
		
		System.out.println(s1 + " " + s1.registerForExam());
		
		String result = s1.appearForExam();
		System.out.println("Result for " + s1 + " is " + result);
		
	}

}
