package abcUniversity;

public class Validator {
	private Validator()
	{
	}
	
	static Validator getValidator() 
	{
	   return new Validator();
	}
	
	boolean validateStudentDetails(Student student)
	{
	  System.out.println("Validated " + student);
	  return true;
	}
}
