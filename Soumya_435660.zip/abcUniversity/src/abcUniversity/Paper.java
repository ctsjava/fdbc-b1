package abcUniversity;
public class Paper {
	private Paper()	{
	}
	static Paper getPaper() 
	{
	   return new Paper();
	}
	String submit()
	{
		  Evaluator evaluator = Evaluator.getEvaluator();
		  return evaluator.evaluate(this);
	}
}
