package abcUniversity;

public class Student {

	private String name; 
	private int age;
	private String maritalStatus; 
	private char sex; 
	private String dob; 
	private String address; 
	private String primaryEmail; 
	public String getMaritalStatus() {
		return maritalStatus;
	}

	public void setMaritalStatus(String maritalStatus) {
		this.maritalStatus = maritalStatus;
	}

	public char getSex() {
		return sex;
	}

	public void setSex(char sex) {
		this.sex = sex;
	}

	public String getDob() {
		return dob;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getPrimaryEmail() {
		return primaryEmail;
	}

	public void setPrimaryEmail(String primaryEmail) {
		this.primaryEmail = primaryEmail;
	}

	public String getSecondaryEmail() {
		return secondaryEmail;
	}

	public void setSecondaryEmail(String secondaryEmail) {
		this.secondaryEmail = secondaryEmail;
	}

	public int getPhNo() {
		return phNo;
	}

	public void setPhNo(int phNo) {
		this.phNo = phNo;
	}

	public String getInterestedSubject() {
		return interestedSubject;
	}

	public void setInterestedSubject(String interestedSubject) {
		this.interestedSubject = interestedSubject;
	}

	public String getHighestEducation() {
		return highestEducation;
	}

	public void setHighestEducation(String highestEducation) {
		this.highestEducation = highestEducation;
	}

	public String getNationality() {
		return nationality;
	}

	public void setNationality(String nationality) {
		this.nationality = nationality;
	}

	private String secondaryEmail; 
	private int phNo; 
	private String interestedSubject; 
	private String highestEducation; 
	private String nationality; 
	
	private int admissionId;
	private String result;
	private Exam exam; 
	
    private Student() 
	{	
	}
	
    static Student getStudent() 
	{
	   return new Student();
	}
	int registerStudent() 
	{
	   Registrar registrar=Registrar.getRegistrar();
	   admissionId = registrar.registerStudent(this);
	   return admissionId;
	 }

	String registerForExam()
	{
	 ExamRegistrar  examRegistrar=ExamRegistrar.getExamRegistrar();
	 exam=examRegistrar.registeringStudentForExamination(this);
	 return "registered for exam";
	}

	String appearForExam()
	{
	Paper paper=exam.getPaper();
	result=paper.submit();
	return result;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public int getAdmissionId() {
		return admissionId;
	}

	public void setAdmissionId(int admissionId) {
		this.admissionId = admissionId;
	}

	public String getResult() {
		return result;
	}

	public void setResult(String result) {
		this.result = result;
	}

	public Exam getExam() {
		return exam;
	}

	public void setExam(Exam exam) {
		this.exam = exam;
	}

	@Override
	public String toString() {
		return "Student [Name=" + name + ", Marital Status=" + maritalStatus + ", age=" + age + ", Sex=" + sex + ", Date of Birth=" + dob + ", Address=" + address + ", Primary Email=" + primaryEmail + ", Secondary Email=" + secondaryEmail + ", Phone Number=" + phNo + ", Interested Subject=" + interestedSubject + ", Highest Education=" + highestEducation + ", Nationality=" + nationality + "]";
	}

	
}
