package abcUniversity;
public class Exam {
	private Exam(){
		
	}
	static Exam getExam(Paper paper1) 	{
		paper=paper1;
		return new Exam();
	}
	static Paper paper;
	
	/*Exam(Paper paper)
	{
		this.paper=paper;
	}
	*/
	Paper getPaper()
	{
	 return paper;
	}
}
