package abcUniversity;

public class ExamRegistrar {
	private ExamRegistrar()	{   
	}
	
	static ExamRegistrar getExamRegistrar()
	{
	 return new ExamRegistrar();
	}
	
	Exam registeringStudentForExamination (Student student)
	{
		Paper paper=Paper.getPaper();
	//	Exam exam=new Exam(paper);
		Exam exam=Exam.getExam(paper);
		return exam;
	}
}
