package com;

public class Notes {
	
	/*
	 * Class relationships
	 * ---------------------
	 * 		1. is 'A'    :-> Inheritance
	 * 		2. has 'A'	 :-> Farward declaration
	 * 
	 *   has 'A'
	 *   ----------
	 *   
	 * 
	 */

}
