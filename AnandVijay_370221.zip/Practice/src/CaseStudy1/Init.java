package CaseStudy1;

import java.util.Scanner;

public class Init {

	public static void main(String[] args) 
	{
		Student s1 = new Student();
		
		System.out.print("Student Name: ");
		Scanner sc = new Scanner(System.in);
		s1.setName(sc.next());
		
		System.out.print("Student maritalstatus: ");
		s1.setMaritalstatus(sc.next());
		
		System.out.print("Student Age: ");
		s1.setAge(sc.nextInt());
		
		System.out.print("Student Sex: ");
		s1.setSex(sc.next());
		
		System.out.print("Student DOB: ");
		s1.setDob(sc.next());
		
		System.out.print("Student Address: ");
		s1.setAddress(sc.next());
		
		System.out.print("Student Primary Mail: ");
		s1.setPmail(sc.next());
		
		System.out.print("Student Secondary Mail: ");
		s1.setSmail(sc.next());
		
		System.out.print("Student Phone: ");
		s1.setPhone(sc.next());
	
		System.out.print("Student Interested Subject: ");
		s1.setInterestedsub(sc.next());
		
		
		System.out.print("Student High Qual: ");
		s1.setHighqual(sc.next());
		
		
		int admissionId = s1.registerStudent();
		System.out.println("Registered " + s1.getName() + " with ID: " + admissionId);
		
		System.out.println(s1 + " " + s1.registerForExam());
		
		String result = s1.appearForExam();
		System.out.println("Result for " + s1.getName() + " is " + result);
		
		sc.close();
		
	}

}
