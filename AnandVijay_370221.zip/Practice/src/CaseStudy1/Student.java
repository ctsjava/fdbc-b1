package CaseStudy1;
public class Student 
{

	private String name; 
	private String maritalstatus; 
	private int age;
	private String sex; 
	private String dob;
	private String address;
	private String pmail;
	private String smail;
	private String phone;
	private String interestedsub;
	private String highqual;
	private String nationality;
	
	private int admissionId;
	private String result;
	private Exam exam; 
	
	public Student() 
	{	
	}
	
	int registerStudent() 
	{
	   Registrar registrar=Registrar.getRegistrar();
	   admissionId = registrar.registerStudent(this);
	   return admissionId;
	 }

	String registerForExam()
	{
	 ExamRegistrar  examRegistrar=ExamRegistrar.getExamRegistrar();
	 exam=examRegistrar.registeringStudentForExamination(this);
	 return "registered for exam";
	}

	String appearForExam()
	{
	Paper paper=exam.getPaper();
	result=paper.submit();
	return result;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	
	public String getMaritalstatus() {
		return maritalstatus;
	}

	public void setMaritalstatus(String maritalstatus) {
		this.maritalstatus = maritalstatus;
	}

	public String getSex() {
		return sex;
	}

	public void setSex(String sex) {
		this.sex = sex;
	}

	public String getDob() {
		return dob;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getPmail() {
		return pmail;
	}

	public void setPmail(String pmail) {
		this.pmail = pmail;
	}

	public String getSmail() {
		return smail;
	}

	public void setSmail(String smail) {
		this.smail = smail;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getInterestedsub() {
		return interestedsub;
	}

	public void setInterestedsub(String interestedsub) {
		this.interestedsub = interestedsub;
	}

	public String getHighqual() {
		return highqual;
	}

	public void setHighqual(String highqual) {
		this.highqual = highqual;
	}

	public String getNationality() {
		return nationality;
	}

	public void setNationality(String nationality) {
		this.nationality = nationality;
	}

	public int getAdmissionId() {
		return admissionId;
	}

	public void setAdmissionId(int admissionId) {
		this.admissionId = admissionId;
	}

	public String getResult() {
		return result;
	}

	public void setResult(String result) {
		this.result = result;
	}

	public Exam getExam() {
		return exam;
	}

	public void setExam(Exam exam) {
		this.exam = exam;
	}

	@Override
	public String toString() {
		return "Student [name=" + name + ", maritalstatus=" + maritalstatus + ", age=" + age + ", sex=" + sex + ","
				+ " "+ "dob=" + dob + ", address=" + address + ", pmail=" + pmail + ", smail=" + smail + ","
				+ " phone=" + phone + ", interestedsub=" + interestedsub + ", highqual=" + highqual + ","
			    + " nationality=" + nationality + "]";
	}


	
		
	}

	

