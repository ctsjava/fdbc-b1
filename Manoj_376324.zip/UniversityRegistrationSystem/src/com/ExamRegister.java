package com;

public class ExamRegister {
	private ExamRegister(){
	}
	public static ExamRegister getExamRegister(){
		return new ExamRegister();
	}

	Exam registeringStudentForExamination(Student student)
	{
		Paper paper = new Paper();
		Exam exam = new Exam(paper);
		return exam;
	}
}
