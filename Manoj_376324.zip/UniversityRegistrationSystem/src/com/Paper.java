package com;

public class Paper {
	String Submit(){
		Evaluator evaluator = Evaluator.getEvaluator();
		return evaluator.evaluate(this);
	}
}
