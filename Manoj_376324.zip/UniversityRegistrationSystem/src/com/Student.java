package com;

public class Student {
	private String Name;
	private String MaritialStatus;
	private Integer Age;
	private String Sex;
	private String DOB;
	private String Address;
	private String PriEmailId;
	private String SecEmailId;
	private String PhoneNumber;
	private String InterestedSubjects;
	private String HighestEduQual;
	private String Nationality;
	
	String AdmissionId;
	String Result;
	Exam exam;
	
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public String getMaritialStatus() {
		return MaritialStatus;
	}
	public void setMaritialStatus(String maritialStatus) {
		MaritialStatus = maritialStatus;
	}
	public Integer getAge() {
		return Age;
	}
	public void setAge(Integer age) {
		Age = age;
	}
	public String getSex() {
		return Sex;
	}
	public void setSex(String sex) {
		Sex = sex;
	}
	
	public Student() {
		
	}
	
	void registerStudent(){
		Register register = Register.getRegister();
		AdmissionId = register.registerStudent(this);
	}
	
	void registerForExam(){
		ExamRegister examRegister = ExamRegister.getExamRegister();
		examRegister.registeringStudentForExamination(this);
		
	}
	
	public String getDOB() {
		return DOB;
	}
	public void setDOB(String dOB) {
		DOB = dOB;
	}
	public String getAddress() {
		return Address;
	}
	public void setAddress(String address) {
		Address = address;
	}
	public String getPriEmailId() {
		return PriEmailId;
	}
	public void setPriEmailId(String priEmailId) {
		PriEmailId = priEmailId;
	}
	public String getSecEmailId() {
		return SecEmailId;
	}
	public void setSecEmailId(String secEmailId) {
		SecEmailId = secEmailId;
	}
	public String getPhoneNumber() {
		return PhoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		PhoneNumber = phoneNumber;
	}
	public String getInterestedSubjects() {
		return InterestedSubjects;
	}
	public void setInterestedSubjects(String interestedSubjects) {
		InterestedSubjects = interestedSubjects;
	}
	public String getHighestEduQual() {
		return HighestEduQual;
	}
	public void setHighestEduQual(String highestEduQual) {
		HighestEduQual = highestEduQual;
	}
	public String getNationality() {
		return Nationality;
	}
	public void setNationality(String nationality) {
		Nationality = nationality;
	}
	public String getAdmissionId() {
		return AdmissionId;
	}
	public void setAdmissionId(String admissionId) {
		AdmissionId = admissionId;
	}
	public String getResult() {
		return Result;
	}
	public void setResult(String result) {
		Result = result;
	}
	public Exam getExam() {
		return exam;
	}
	public void setExam(Exam exam) {
		this.exam = exam;
	}
	void appearForExam(){
		Paper paper = exam.getPaper();
		Result = paper.Submit();
	}
	
	@Override
	public String toString(){
		return "Student [name=" + Name + ", age=" + Age + "]";
	}

}
