package com;

public class Validator {
	private Validator(){
		
	}
	public static  Validator getValidator()
	{
		return new Validator();
	}
	
	boolean validateStudentDetails(Student student){
		return true;
	}

}
