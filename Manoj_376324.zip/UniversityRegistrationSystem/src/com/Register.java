package com;

public class Register {
	private Integer seqNum;
	private Register(){
		setSeqNum(0);
	}
	public static Register getRegister()
	{
		return new Register();
	}
	
	public String registerStudent(Student student){
		String admissionid = null;
		Validator validator = Validator.getValidator();
		if (validator.validateStudentDetails(student))
		{
		    //generate admission id and return it to the student
			seqNum = seqNum + 1;
			admissionid = "ADM" + seqNum;
			return admissionid;

		}
		return null;
	}
	public Integer getSeqNum() {
		return seqNum;
	}
	public void setSeqNum(Integer seqNum) {
		this.seqNum = seqNum;
	}

}
