package com;

public class TestDemo {

	public static void main(String[] args) {

		Student student = new Student();
		
		student.setName("Pankoj Chowdhury");
		student.setMaritialStatus("Unmarried");
		student.setAge(22);
		student.setSex("Male");
		student.setDOB("12-Mar-1988");
		student.setAddress("Koipukuria");
		student.setPriEmailId("pankaj@gmail.com");
		student.setSecEmailId("Pankoj@yahoo.com");
		student.setPhoneNumber("9988776655");
		student.setInterestedSubjects("Physics, Chemistry, Mathematics");
		student.setHighestEduQual("B.Sc.");
		student.setNationality("Indian");
		
		System.out.println(student);
		
		String AdmId = Register.getRegister().registerStudent(student);
		
		System.out.println("Admission Id: " + AdmId);
		
		Exam exam = ExamRegister.getExamRegister().registeringStudentForExamination(student);
		
		student.setExam(exam);
		
		student.appearForExam();
		
		System.out.println("Result: " + student.getResult());
		

	}

}
