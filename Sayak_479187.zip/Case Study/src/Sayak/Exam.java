package Sayak;
public class Exam {
	static Paper paper;
	private Exam(){
		
		}
	static Exam getExam(Paper paper1){
		paper=paper1;
		return new Exam();
		
	}
	Paper getPaper(){
		 return paper;
		}
} 
