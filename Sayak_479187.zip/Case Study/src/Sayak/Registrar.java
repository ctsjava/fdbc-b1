package Sayak;

public class Registrar 
{
	private int id = 0;
	
	private Registrar()
	{	   
	}
	
	static Registrar getRegistrar()
	{
	 return new Registrar();
	}

	 int registerStudent(Student student)
	 {
	  Validator validator=Validator.getValidator();
	
	  if(validator.validateStudentDetails(student))
	  {
		 id =  student.hashCode();
	  }
	  return id;	  
	 }

}
