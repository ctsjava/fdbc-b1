package Sayak;
import java.util.Scanner;

public class Apply {

	public static void main(String[] args) 
	{
		Student s1 = Student.getStudent();
		
		System.out.print("Enter name: ");
		Scanner sc = new Scanner(System.in);
		s1.setName(sc.next());
		s1.setAddress("Kolkata");
		s1.setAge(35);
		s1.setDOB("MM/DD/YYYY");
		s1.setHighestQualification("Btech");
		s1.setInterestedSubject("Electronics and Communication");
		s1.setMaritalStatus('U');
		s1.setName("Sayak Som");
		s1.setNationality("Indian");
		s1.setPhoneNumber(8981777976l);
		s1.setPrimaryEmailId("deepnil.92@gmail.com");
		s1.setSecondaryEmailId("sayak.som1992@gmail.com");
		s1.setSex('M');
		
		int admissionId = s1.registerStudent();
		System.out.println("Registered " + s1 + " with ID: " + admissionId);
		
		System.out.println(s1 + " " + s1.registerForExam());
		
		String result = s1.appearForExam();
		System.out.println("Result for " + s1 + " is " + result);
		
		
		   
	}

}
