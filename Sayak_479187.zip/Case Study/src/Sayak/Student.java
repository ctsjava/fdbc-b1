package Sayak;

public class Student 
{

	private String name;
	private char MaritalStatus;
	private int age;
	private char Sex;
	private String DOB;
	private String Address;
	private String PrimaryEmailId; 
	private String SecondaryEmailId;
	private long PhoneNumber;
	private String InterestedSubject;
	private String HighestQualification;
	private String Nationality;
	private int admissionId;
	private String result;
	public char getMaritalStatus() {
		return MaritalStatus;
	}

	public void setMaritalStatus(char maritalStatus) {
		MaritalStatus = maritalStatus;
	}

	public char getSex() {
		return Sex;
	}

	public void setSex(char sex) {
		Sex = sex;
	}

	public String getDOB() {
		return DOB;
	}

	public void setDOB(String dOB) {
		DOB = dOB;
	}

	public String getAddress() {
		return Address;
	}

	public void setAddress(String address) {
		Address = address;
	}

	public String getPrimaryEmailId() {
		return PrimaryEmailId;
	}

	public void setPrimaryEmailId(String primaryEmailId) {
		PrimaryEmailId = primaryEmailId;
	}

	public String getSecondaryEmailId() {
		return SecondaryEmailId;
	}

	public void setSecondaryEmailId(String secondaryEmailId) {
		SecondaryEmailId = secondaryEmailId;
	}

	public long getPhoneNumber() {
		return PhoneNumber;
	}

	public void setPhoneNumber(long phoneNumber) {
		PhoneNumber = phoneNumber;
	}

	public String getInterestedSubject() {
		return InterestedSubject;
	}

	public void setInterestedSubject(String interestedSubject) {
		InterestedSubject = interestedSubject;
	}

	public String getHighestQualification() {
		return HighestQualification;
	}

	public void setHighestQualification(String highestQualification) {
		HighestQualification = highestQualification;
	}

	public String getNationality() {
		return Nationality;
	}

	public void setNationality(String nationality) {
		Nationality = nationality;
	}

	private Exam exam; 
    private Student() 
	{	
	}
	
    static Student getStudent() 
	{
	   return new Student();
	}
	int registerStudent() 
	{
	   Registrar registrar=Registrar.getRegistrar();
	   admissionId = registrar.registerStudent(this);
	   return admissionId;
	 }

	String registerForExam()
	{
	 ExamRegistrar  examRegistrar=ExamRegistrar.getExamRegistrar();
	 exam=examRegistrar.registeringStudentForExamination(this);
	 return "registered for exam";
	}

	String appearForExam()
	{
	Paper paper=exam.getPaper();
	result=paper.submit();
	return result;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public int getAdmissionId() {
		return admissionId;
	}

	public void setAdmissionId(int admissionId) {
		this.admissionId = admissionId;
	}

	public String getResult() {
		return result;
	}

	public void setResult(String result) {
		this.result = result;
	}

	public Exam getExam() {
		return exam;
	}

	public void setExam(Exam exam) {
		this.exam = exam;
	}

	@Override
	public String toString() {
		return "Student [name=" + name + " MaritalStatus=" + MaritalStatus + " Age=" + age + " Sex = " + Sex + " DOB= " + DOB + " Address= " + Address + " PrimaryEmailId = " + PrimaryEmailId + " SecondaryEmailId = " + SecondaryEmailId + " PhoneNumber = " + PhoneNumber + " InterestedSubject = " + InterestedSubject +  " HighestQualification = " + HighestQualification + " Nationality = " + Nationality + "]";
	}
                               
	
}
