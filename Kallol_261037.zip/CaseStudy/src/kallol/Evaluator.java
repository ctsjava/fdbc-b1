package kallol;

public class Evaluator 
{
	private Evaluator()
	{   
	}
	
	static Evaluator getEvaluator()
	{
	 return new Evaluator();
	} 

	String evaluate(Paper paper)
	{
	  return "Pass";
	}
}
