package kallol;


	import java.util.Scanner;

	public class Driver {

		public static void main(String[] args) 
		{
			Student s1 = new Student();
			
			System.out.print("Enter name of the student: ");
			Scanner sc = new Scanner(System.in);
			//Scanner sc1 = new Scanner(System.in);
			s1.setName(sc.next());
			System.out.println("Enter age of the student: ");
			//int age = sc.nextInt();
			s1.setAge(sc.nextInt());		
			int admissionId = s1.registerStudent();
			System.out.println("Registered  " + s1 + " with ID: " + admissionId);
			
			System.out.println(s1 + " " + s1.registerForExam());
			
			String result = s1.appearForExam();
			System.out.println("Result for " + s1 + " is " + result);
			
			
			
		}

	}



