package kallol;

import java.util.Random;

public class Registrar 
{
	private int id = 0;
	Random 	rand = new Random();
	
	private Registrar()
	{	   
	}
	
	static Registrar getRegistrar()
	{
	 return new Registrar();
	}

	 int registerStudent(Student student)
	 {
	  Validator validator=Validator.getValidator();
	
	  if(validator.validateStudentDetails(student))
	  {
		 //id =  student.hashCode();
		id =  rand.nextInt(9999);
		System.out.println(" Random function");
	  }
	  return id;	  
	 }

}
