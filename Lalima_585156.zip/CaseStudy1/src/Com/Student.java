package Com;

public class Student 
{

	private String name; 
	private int age; 
	private String maritalStatus;
	private String sex;
	private String DOB; 
	private String address;
	private String primaryEmailId;
	private String secondaryEmailId;
	private String phoneNumber;
	private String interestedSubject;
	private String highestEducationQualification;
	private String nationality;

	
	private int admissionId;
	private String result;
	private Exam exam; 
	
	public Student() 
	{	
	}
	
	int registerStudent() 
	{
	   Registrar registrar=Registrar.getRegistrar();
	   admissionId = registrar.registerStudent(this);
	   return admissionId;
	 }

	String registerForExam()
	{
	 ExamRegistrar  examRegistrar=ExamRegistrar.getExamRegistrar();
	 exam=examRegistrar.registeringStudentForExamination(this);
	 return "registered for exam";
	}

	String appearForExam()
	{
	Paper paper=exam.getPaper();
	result=paper.submit();
	return result;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public int getAdmissionId() {
		return admissionId;
	}

	public void setAdmissionId(int admissionId) {
		this.admissionId = admissionId;
	}

	public String getResult() {
		return result;
	}

	public void setResult(String result) {
		this.result = result;
	}

	public Exam getExam() {
		return exam;
	}

	public void setExam(Exam exam) {
		this.exam = exam;
	}

	@Override
	public String toString() {
		return "Student [name=" + name + ", age=" + age + "]";
	}

	public String getMaritalStatus() {
		return maritalStatus;
	}

	public void setMaritalStatus(String maritalStatus) {
		this.maritalStatus = maritalStatus;
	}

	public String getSex() {
		return sex;
	}

	public void setSex(String sex) {
		this.sex = sex;
	}

	public String getDOB() {
		return DOB;
	}

	public void setDOB(String dOB) {
		DOB = dOB;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getPrimaryEmailId() {
		return primaryEmailId;
	}

	public void setPrimaryEmailId(String primaryEmailId) {
		this.primaryEmailId = primaryEmailId;
	}

	public String getSecondaryEmailId() {
		return secondaryEmailId;
	}

	public void setSecondaryEmailId(String secondaryEmailId) {
		this.secondaryEmailId = secondaryEmailId;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getInterestedSubject() {
		return interestedSubject;
	}

	public void setInterestedSubject(String interestedSubject) {
		this.interestedSubject = interestedSubject;
	}

	public String getHighestEducationQualification() {
		return highestEducationQualification;
	}

	public void setHighestEducationQualification(
			String highestEducationQualification) {
		this.highestEducationQualification = highestEducationQualification;
	}

	public String getNationality() {
		return nationality;
	}

	public void setNationality(String nationality) {
		this.nationality = nationality;
	}

	
}
