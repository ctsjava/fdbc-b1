package admission;

public class Evaluator {
		private Evaluator(){
			
		}
		public static Evaluator getEvaluator(){
		 return new Evaluator();
		} 

		//As per assumption all applied student will pass the exam
		String evaluate(Paper paper){
		  return "pass";
		}
}

