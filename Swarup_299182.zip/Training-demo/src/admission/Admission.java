package admission;

public class Admission {

	public static void main(String[] args) {
		Student s = Student.getStudent();

		//set student class variables
		s.setAddress("Nadia");
		s.setAge(29);
		s.setDateOfBirth("XX/XX/XXXX");
		s.setHighestQualification("Btech");
		s.setInterestedSubject("Computer science");
		s.setMaritalStatus('M');
		s.setName("Swarup Mondal");
		s.setNationality("Indian");
		s.setPhoneNumber(9999999999l);
		s.setPrimaryEmailId("Swarupmondal.ZZZZZZ@gmail.com");
		s.setSecondaryEmailId("Swarup.Mondal@cognizant.com");
		s.setSex('M');
		s.setAdmissionId(s.registerStudent());
		s.registerForExam();
		s.setResult(s.appearForExam());
		
		//display all the information about student
		Student.display(s);

	}

}
