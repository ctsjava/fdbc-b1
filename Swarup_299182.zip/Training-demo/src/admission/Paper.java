package admission;

public class Paper {
		private Paper(){
		   
		}
		static Paper getPaper(){
			return new Paper();
		}
		 String submit(){
		  Evaluator evaluator=Evaluator.getEvaluator();
		  String result=evaluator.evaluate(this);
		  return result;
		}
}
