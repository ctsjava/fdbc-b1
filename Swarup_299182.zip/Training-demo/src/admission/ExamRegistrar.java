package admission;

public class ExamRegistrar {
		private ExamRegistrar(){   }
		public static ExamRegistrar getExamRegistrar(){
		 return new ExamRegistrar();
		} 
		Exam registeringStudentForExamination (Student student){
			Paper paper=Paper.getPaper();
			Exam exam=Exam.getExam(paper);
			return exam;
		}

		}
