package admission;

public class Student {
	private String Name; 
	private char MaritalStatus;
	private int Age;
	private char Sex;
	private String DateOfBirth; 
	private String Address;
	private String PrimaryEmailId; 
	private String SecondaryEmailId;
	private long PhoneNumber;
	private String InterestedSubject;
	private String HighestQualification;
	private String Nationality;
	private String admissionId;
	private String result;
	private Exam exam; 
	private Student () //student constructor
	{
	 //assign student details to the member variables
	}
	static Student getStudent() {
		   return new Student();
		}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		this.Name = name;
	}
	public char getMaritalStatus() {
		return MaritalStatus;
	}
	public void setMaritalStatus(char maritalStatus) {
		this.MaritalStatus = maritalStatus;
	}
	public int getAge() {
		return Age;
	}
	public void setAge(int age) {
		this.Age = age;
	}
	public char getSex() {
		return Sex;
	}
	public void setSex(char sex) {
		this.Sex = sex;
	}
	public String getDateOfBirth() {
		return DateOfBirth;
	}
	public void setDateOfBirth(String dateOfBirth) {
		this.DateOfBirth = dateOfBirth;
	}
	public String getAddress() {
		return Address;
	}
	public void setAddress(String address) {
		this.Address = address;
	}
	public String getPrimaryEmailId() {
		return PrimaryEmailId;
	}
	public void setPrimaryEmailId(String primaryEmailId) {
		this.PrimaryEmailId = primaryEmailId;
	}
	public String getSecondaryEmailId() {
		return SecondaryEmailId;
	}
	public void setSecondaryEmailId(String secondaryEmailId) {
		this.SecondaryEmailId = secondaryEmailId;
	}
	public long getPhoneNumber() {
		return PhoneNumber;
	}
	public void setPhoneNumber(long phoneNumber) {
		this.PhoneNumber = phoneNumber;
	}
	public String getInterestedSubject() {
		return InterestedSubject;
	}
	public void setInterestedSubject(String interestedSubject) {
		this.InterestedSubject = interestedSubject;
	}
	public String getHighestQualification() {
		return HighestQualification;
	}
	public void setHighestQualification(String highestQualification) {
		this.HighestQualification = highestQualification;
	}
	public String getNationality() {
		return Nationality;
	}
	public void setNationality(String nationality) {
		this.Nationality = nationality;
	}
	public String getAdmissionId() {
		return admissionId;
	}
	public void setAdmissionId(String admissionId) {
		this.admissionId = admissionId;
	}
	public String getResult() {
		return result;
	}
	public void setResult(String result) {
		this.result = result;
	}
	public Exam getExam() {
		return exam;
	}
	public void setExam(Exam exam) {
		this.exam = exam;
	}
	//Register student
	String registerStudent() {
	   Registrar registrar=Registrar.getRegistrar();
	   admissionId = registrar. registerStudent(this);
	   return admissionId;
	   //setAdmissionId(admissionId);
//	   System.out.println("Allotted admission ID: "+admissionId);
	  }
	//Register for Exam
	void registerForExam(){
	 ExamRegistrar  examRegistrar=ExamRegistrar.getExamRegistrar();
	 exam=examRegistrar.registeringStudentForExamination(this);
	 //return exam;
	}
	
	//Appear for Exam
	String appearForExam(){
	Paper paper=exam.getPaper();
	result=paper.submit();
	return result;
	//setResult(result);
	//System.out.println("Result of the exam: "+result);
	}
	static void display(Student s){
		System.out.println("Details of the student:");
		System.out.println("--------------");
		System.out.println("Name: "+s.getName());
		System.out.println("Primary Email:"+s.getPrimaryEmailId());
		System.out.println("Sex: "+s.getSex());
		System.out.println("Nationality: "+s.getNationality());
		System.out.println("Address: "+s.getAddress());
		System.out.println("Contact no:"+s.getPhoneNumber());
		System.out.println("DOB:"+s.getDateOfBirth());
		System.out.println("Subject applied for:"+s.getInterestedSubject());
		
		System.out.println("");
		System.out.println("-------------------");
		System.out.println("Results for the student:"+s.getName());
		System.out.println("Admission ID:"+s.getAdmissionId());
		//System.out.println("Exam: "+s.getExam());
		System.out.println("Result: "+s.getResult());
		
	}
		}

