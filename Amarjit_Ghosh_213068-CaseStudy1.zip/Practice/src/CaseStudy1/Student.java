package CaseStudy1;

import java.util.Scanner;

public class Student 
{

	private String name; 
	private int age;
	
	private int admissionId;
	private String result;
	private Exam exam; 
	
	public Student() 
	{	
	}
	
	int registerStudent() 
	{
	   Registrar registrar=Registrar.getRegistrar();
	   admissionId = registrar.registerStudent(this);
	   return admissionId;
	 }

	String registerForExam()
	{
	 ExamRegistrar  examRegistrar=ExamRegistrar.getExamRegistrar();
	 exam=examRegistrar.registeringStudentForExamination(this);
	 return "registered for exam";
	}

	String appearForExam()
	{
	Paper paper=exam.getPaper();
	result=paper.submit();
	return result;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public int getAdmissionId() {
		return admissionId;
	}

	public void setAdmissionId(int admissionId) {
		this.admissionId = admissionId;
	}

	public String getResult() {
		return result;
	}

	public void setResult(String result) {
		this.result = result;
	}

	public Exam getExam() {
		return exam;
	}

	public void setExam(Exam exam) {
		this.exam = exam;
	}

	@Override
	public String toString() {
		return "Student [name=" + name + ", age=" + age + "]";
	}


	
		
	}

	

