package CaseStudy1;

import java.util.Scanner;

public class Init {

	public static void main(String[] args) 
	{
		Student s1 = new Student();
		
		System.out.print("Student Name: ");
		Scanner sc = new Scanner(System.in);
		s1.setName(sc.next());
		
		System.out.print("Student Age: ");
		s1.setAge(sc.nextInt());
		
		int admissionId = s1.registerStudent();
		System.out.println("Registered " + s1 + " with ID: " + admissionId);
		
		System.out.println(s1 + " " + s1.registerForExam());
		
		String result = s1.appearForExam();
		System.out.println("Result for " + s1 + " is " + result);
		
		
		
	}

}
