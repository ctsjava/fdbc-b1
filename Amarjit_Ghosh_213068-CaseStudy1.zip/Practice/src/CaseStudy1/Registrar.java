package CaseStudy1;
import java.util.Random; 

public class Registrar 
{
	private int id = 0;
	Random rand = new Random(); 
	private Registrar()
	{	   
	}
	
	static Registrar getRegistrar()
	{
	 return new Registrar();
	}

	 int registerStudent(Student student)
	 {
	  Validator validator=Validator.getValidator();
	
	  if(validator.validateStudentDetails(student))
	  {
	//	 id =  student.hashCode();
         id =  rand.nextInt(1000000);
	  }
	  return id;	  
	 }

}
