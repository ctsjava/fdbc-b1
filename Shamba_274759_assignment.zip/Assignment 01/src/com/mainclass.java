package com;

import java.util.ArrayList;


public class mainclass {

	public static void main(String[] args) {
		
		ArrayList <Student> la = new ArrayList<>();
		
		Student s1 = new Student("shamba",'M',34,'M',"121314","KOLKATA","ABC@DEF.COM","GHI@JKL.COM","1234567890","MATH","BTECH","INDIAN");
		Student s2 = new Student("shamba1",'M',34,'M',"121314","KOLKATA","ABC@DEF.COM","GHI@JKL.COM","1234567890","MATH","BTECH","INDIAN");
				
		la.add(s1);
		la.add(s2);
		
		for(Student s:la){
		
		s.registerStudent();
		s.registerForExam();
		s.appearForExam();

		
		System.out.println("name: " 		+ s.getName());
		System.out.println("admissionId: " 	+ s.getAdmissionId());
		System.out.println("result of the exam is: " + s.getResult());
		System.out.println("---------------------------------------");
		}
		
		
	}

}
