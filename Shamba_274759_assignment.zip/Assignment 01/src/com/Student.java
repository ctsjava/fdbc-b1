package com;

public class	Student	{
	private String Name; 
	private char Marital_Status;
	private int Age;
	private char Sex;
	private String Date_of_Birth; 
	private String Address;
	private String Primary_Email_id; 
	private String Secondary_Email_id;
	private String Phone_Number;
	private String Interested_Subject;
	private String Highest_Education_Qualification;
	private String Nationality;
	private String admissionId;
	private String result;
	private Exam exam; 
	
	/**
	 * @param name
	 * @param marital_Status
	 * @param age
	 * @param sex
	 * @param date_of_Birth
	 * @param address
	 * @param primary_Email_id
	 * @param secondary_Email_id
	 * @param phone_Number
	 * @param interested_Subject
	 * @param highest_Education_Qualification
	 * @param nationality
	 */
	public Student(String name, char marital_Status, int age, char sex,
			String date_of_Birth, String address, String primary_Email_id,
			String secondary_Email_id, String phone_Number,
			String interested_Subject, String highest_Education_Qualification,
			String nationality) {
		super();
		Name = name;
		Marital_Status = marital_Status;
		Age = age;
		Sex = sex;
		Date_of_Birth = date_of_Birth;
		Address = address;
		Primary_Email_id = primary_Email_id;
		Secondary_Email_id = secondary_Email_id;
		Phone_Number = phone_Number;
		Interested_Subject = interested_Subject;
		Highest_Education_Qualification = highest_Education_Qualification;
		Nationality = nationality;
	}
	
	void registerStudent() {
	   Registrar registrar=Registrar.getRegistrar();
	   admissionId = registrar.registerStudent(this);
	  }

	void registerForExam (){
	 ExamRegistrar  examRegistrar=ExamRegistrar.getExamRegistrar();
	 exam=examRegistrar.registeringStudentForExamination(this);
	}

	void appearForExam(){
		Paper paper=exam.getPaper();
		result=paper.submit();
	}

	public String getName() {
		return Name;
	}

	public void setName(String name) {
		Name = name;
	}

	public char getMarital_Status() {
		return Marital_Status;
	}

	public void setMarital_Status(char marital_Status) {
		Marital_Status = marital_Status;
	}

	public int getAge() {
		return Age;
	}

	public void setAge(int age) {
		Age = age;
	}

	public char getSex() {
		return Sex;
	}

	public void setSex(char sex) {
		Sex = sex;
	}

	public String getDate_of_Birth() {
		return Date_of_Birth;
	}

	public void setDate_of_Birth(String date_of_Birth) {
		Date_of_Birth = date_of_Birth;
	}

	public String getAddress() {
		return Address;
	}

	public void setAddress(String address) {
		Address = address;
	}

	public String getPrimary_Email_id() {
		return Primary_Email_id;
	}

	public void setPrimary_Email_id(String primary_Email_id) {
		Primary_Email_id = primary_Email_id;
	}

	public String getSecondary_Email_id() {
		return Secondary_Email_id;
	}

	public void setSecondary_Email_id(String secondary_Email_id) {
		Secondary_Email_id = secondary_Email_id;
	}

	public String getPhone_Number() {
		return Phone_Number;
	}

	public void setPhone_Number(String phone_Number) {
		Phone_Number = phone_Number;
	}

	public String getInterested_Subject() {
		return Interested_Subject;
	}

	public void setInterested_Subject(String interested_Subject) {
		Interested_Subject = interested_Subject;
	}

	public String getHighest_Education_Qualification() {
		return Highest_Education_Qualification;
	}

	public void setHighest_Education_Qualification(
			String highest_Education_Qualification) {
		Highest_Education_Qualification = highest_Education_Qualification;
	}

	public String getNationality() {
		return Nationality;
	}

	public void setNationality(String nationality) {
		Nationality = nationality;
	}

	public String getAdmissionId() {
		return admissionId;
	}

	public void setAdmissionId(String admissionId) {
		this.admissionId = admissionId;
	}

	public String getResult() {
		return result;
	}

	public void setResult(String result) {
		this.result = result;
	}

	public Exam getExam() {
		return exam;
	}

	public void setExam(Exam exam) {
		this.exam = exam;
	}
	
	
	
}
