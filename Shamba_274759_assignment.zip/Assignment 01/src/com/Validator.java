package com;

public class Validator {
	private Validator(){
	   }
	static Validator getValidator() {
	   return new Validator();
	}
	boolean validateStudentDetails(Student student){
	   System.out.println("student " + student.getName() + " is validated");
	   return true;
	}
}