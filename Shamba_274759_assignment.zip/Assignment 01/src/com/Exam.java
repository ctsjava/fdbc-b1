package com;

public class Exam{
	private Paper paper;
	Exam(Paper paper){
	this.paper=paper;
	}
	Paper getPaper(){
	 return paper;
	}
}